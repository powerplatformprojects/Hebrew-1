# Hebrew Verb Builder

GitHub Pages-ready Hebrew verb conjugation and speech-practice app.

## Publish with GitHub Pages

1. Create a new GitHub repository.
2. Upload `index.html` and this `README.md` to the repository root.
3. In GitHub, open **Settings > Pages**.
4. Under **Build and deployment**, choose **Deploy from a branch**.
5. Select branch **main** and folder **/(root)**, then save.
6. After GitHub finishes deploying, open the Pages URL shown in that section.

## Browser notes

- Microphone and speech recognition require HTTPS. GitHub Pages provides HTTPS.
- Chrome or Edge generally provide the best support for browser speech recognition.
- Allow microphone access when prompted.

## App behavior

- Choose a Hebrew verb and tense.
- Select a pronoun/conjugation.
- Use **Hear it** to hear the Hebrew form.
- Use **Say it** for speech recognition practice.
- **Next** advances through conjugations and then moves to the next word.
- Progress is stored locally in the browser.
